from robocat.model import Robocat
from robocat.train import Train