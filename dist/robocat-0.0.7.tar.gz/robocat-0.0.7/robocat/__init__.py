from robocat.model import RoboCat
